

<?php
wp_enqueue_style( 'style-name', get_stylesheet_uri() );
wp_enqueue_style( 'style-boot', get_template_directory_uri() . '/assets/css/bootstrap.min.css' );
wp_enqueue_script( 'script-name-2', get_template_directory_uri() . '/assets/js/bootstrap.bundle.min.js', array(), '1.0.0', true );

add_theme_support( 'title-tag' );
add_theme_support( 'custom-logo', array(
    'height' => 480,
    'width'  => 720,
) );

add_theme_support( 'post-thumbnails' );
add_theme_support( 'post-thumbnails', array( 'post' ) );          // Posts only
add_theme_support( 'post-thumbnails', array( 'page' ) );          // Pages only
add_theme_support( 'post-thumbnails', array( 'post', 'movie' ) ); // Posts and Movies

register_nav_menus( array(
    'PM'=>'Primary'
) );

register_sidebar([
    'name'=>'BD Logo',
    'id'=>'bdlogo',
    'before_widget'  => '',
    'after_widget'   => '',
 ]);
register_sidebar([
    'name'=>'hero titlr',
    'id'=>'herotitle',
    'before_widget'  => '',
    'after_widget'   => '',
 ]);
register_sidebar([
    'name'=>'card image',
    'id'=>'cardimg1',
    'before_widget'  => '',
    'after_widget'   => '',
 ]);
register_sidebar([
    'name'=>'card Image-2',
    'id'=>'cardimg2',
    'before_widget'  => '',
    'after_widget'   => '',
 ]);
register_sidebar([
    'name'=>'card Image-3',
    'id'=>'cardimg3',
    'before_widget'  => '',
    'after_widget'   => '',
 ]);
register_sidebar([
    'name'=>'image 1',
    'id'=>'image1',
    'before_widget'  => '',
    'after_widget'   => '',
 ]);
register_sidebar([
    'name'=>'image title',
    'id'=>'imagetitle',
    'before_widget'  => '',
    'after_widget'   => '',
 ]);
register_sidebar([
    'name'=>'Image-2',
    'id'=>'image2',
    'before_widget'  => '',
    'after_widget'   => '',
 ]);
register_sidebar([
    'name'=>'Image-10',
    'id'=>'image10',
    'before_widget'  => '',
    'after_widget'   => '',
 ]);
register_sidebar([
    'name'=>'Image-11',
    'id'=>'image11',
    'before_widget'  => '',
    'after_widget'   => '',
 ]);
register_sidebar([
    'name'=>'Image-12',
    'id'=>'image12',
    'before_widget'  => '',
    'after_widget'   => '',
 ]);
register_sidebar([
    'name'=>'Image-13',
    'id'=>'image13',
    'before_widget'  => '',
    'after_widget'   => '',
 ]);


?>